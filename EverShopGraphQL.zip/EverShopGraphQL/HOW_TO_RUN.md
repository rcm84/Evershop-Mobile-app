# How to Run This Mobile App

## ⚠️ Important: This is a Mobile App

This project is a **React Native mobile application** - it is NOT a web application and cannot be viewed in a browser.

## Prerequisites

Before you can run this app, you need ONE of the following:

### Option 1: Physical Device (Easiest for Testing)
- An iPhone or Android phone
- Expo Go app installed:
  - iOS: [Download from App Store](https://apps.apple.com/app/expo-go/id982107779)
  - Android: [Download from Google Play](https://play.google.com/store/apps/details?id=host.exp.exponent)

### Option 2: Emulator/Simulator
- **Android Studio** with Android Emulator configured
- **Xcode** with iOS Simulator (macOS only)

## Running the App

### Step 1: Install Dependencies

```bash
npm install
```

### Step 2: Start Development Server

```bash
npm start
```

This will:
1. Start the Metro bundler
2. Display a QR code
3. Provide options to run on different platforms

### Step 3: Open on Your Device

#### Using Physical Device:

**Android:**
1. Open Expo Go app
2. Tap "Scan QR code"
3. Scan the QR code from terminal

**iOS:**
1. Open Camera app
2. Scan the QR code from terminal
3. Tap the notification to open in Expo Go

#### Using Emulator:

**Android Emulator:**
```bash
npm run android
```

**iOS Simulator (macOS only):**
```bash
npm run ios
```

## Alternative: Web Preview (Limited)

While this is a mobile app, Expo does support a limited web version:

```bash
npm run web
```

**Note:** Web version may have limitations and is primarily for quick previews. Native features like SecureStore may not work properly.

## Troubleshooting

### "Cannot connect to Metro bundler"
- Ensure your phone and computer are on the same Wi-Fi network
- Check firewall settings
- Try running with tunnel: `npm start -- --tunnel`

### "Module not found"
- Clear cache: `expo start --clear`
- Reinstall: `rm -rf node_modules && npm install`

### "Build errors"
- Update Expo SDK: `npm install expo@latest`
- Check Node version: `node --version` (should be 20+)

## Configuration

### Change Backend API URL

1. Edit `app.json`:
```json
{
  "expo": {
    "extra": {
      "storeApiUrl": "https://your-backend-url.com/api/graphql"
    }
  }
}
```

2. Or use the Settings screen in the app after launch

### Demo Credentials

- Email: `demo@evershop.io`
- Password: `demo123`

## Building for Production

See `DEPLOYMENT.md` for instructions on building APK/IPA files for distribution.

## Questions?

- Read `README.md` for full documentation
- Check [Expo Documentation](https://docs.expo.dev/)
- Review `DEPLOYMENT.md` for deployment options
