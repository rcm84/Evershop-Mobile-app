# EverShop Mobile - React Native E-commerce App

A complete React Native + Expo mobile application that consumes the EverShop GraphQL API. Built with TypeScript, featuring authentication, product browsing, shopping cart, checkout flow, and a flexible theming system.

## Features

- ✅ **Authentication**: Login/Logout with JWT stored securely in SecureStore
- ✅ **Product Browsing**: Paginated product listings with search and category filtering
- ✅ **Product Details**: Images, variants, pricing, and add-to-cart functionality
- ✅ **Shopping Cart**: Persistent cart with AsyncStorage and backend synchronization
- ✅ **Checkout Flow**: Order creation with result display
- ✅ **Theming System**: JSON token-based theming for easy customization
- ✅ **Multi-Instance Support**: Runtime configuration of STORE_API_URL
- ✅ **TypeScript**: Fully typed codebase
- ✅ **Testing**: Jest + React Native Testing Library setup

## Tech Stack

- **React Native** - Mobile framework
- **Expo** - Development and build toolchain
- **TypeScript** - Type safety
- **Apollo Client** - GraphQL client
- **React Navigation** - Navigation
- **Expo SecureStore** - Secure JWT storage
- **AsyncStorage** - Local cart persistence
- **Jest** - Testing framework

## Project Structure

```
/
├── src/
│   ├── apollo/          # Apollo Client configuration
│   │   └── client.ts
│   ├── components/      # Reusable components
│   │   ├── Header.tsx
│   │   ├── ProductCard.tsx
│   │   ├── QuantityPicker.tsx
│   │   └── ThemeProvider.tsx
│   ├── graphql/         # GraphQL queries and mutations
│   │   ├── queries.ts
│   │   └── mutations.ts
│   ├── hooks/           # Custom React hooks
│   │   ├── useAuth.ts
│   │   └── useCart.ts
│   ├── screens/         # Screen components
│   │   ├── Home.tsx
│   │   ├── Product.tsx
│   │   ├── Cart.tsx
│   │   ├── Checkout.tsx
│   │   ├── Login.tsx
│   │   └── Settings.tsx
│   ├── themes/          # Theme configuration
│   │   └── default.json
│   ├── utils/           # Utility functions
│   │   └── storage.ts
│   └── App.tsx          # Main app component
├── __tests__/           # Test files
├── app.json             # Expo configuration
├── package.json
├── tsconfig.json
└── README.md
```

## Installation

1. **Install dependencies**:
```bash
npm install
```

2. **Start the development server**:
```bash
npm start
# or
expo start
```

3. **Run on device/emulator**:
```bash
npm run android  # For Android
npm run ios      # For iOS (macOS only)
```

## Configuration

### Change STORE_API_URL

There are two ways to configure the GraphQL API endpoint:

#### Method 1: Via app.json (Development)

Edit `app.json` and update the `extra.storeApiUrl` value:

```json
{
  "expo": {
    "extra": {
      "storeApiUrl": "https://your-store.com/api/graphql"
    }
  }
}
```

#### Method 2: Runtime Configuration (Recommended)

1. Launch the app
2. Navigate to Settings screen
3. Update the "GraphQL API URL" field
4. Click "Save Changes"
5. Restart the app for changes to take effect

### Demo Credentials

The app includes demo credentials for testing:

- **Email**: demo@evershop.io
- **Password**: demo123

*Note: These credentials work with the EverShop demo backend. For your own backend, use actual user credentials.*

## GraphQL API

The app expects the following GraphQL operations to be available:

### Queries

- `products` - Get paginated product list with search and filters
- `product` - Get single product by slug
- `categories` - Get category list
- `cart` - Get current cart
- `customer` - Get authenticated customer info

### Mutations

- `login` - Authenticate user and receive JWT token
- `logout` - End user session
- `addToCart` - Add product to cart
- `updateCartItem` - Update cart item quantity
- `removeCartItem` - Remove item from cart
- `createOrder` - Create new order from cart

*Note: Field names in the GraphQL schema may vary. Update the queries in `src/graphql/` to match your backend schema.*

## Theming

The app uses a token-based theming system defined in `src/themes/default.json`:

```json
{
  "colors": {
    "primary": "#007AFF",
    "secondary": "#5856D6",
    ...
  },
  "typography": {
    "fontSize": { ... },
    "fontWeight": { ... }
  },
  "spacing": { ... },
  "borderRadius": { ... }
}
```

To customize the theme:

1. Edit `src/themes/default.json`
2. Or create a new theme file and update the import in `src/components/ThemeProvider.tsx`

## Testing

Run the test suite:

```bash
npm test
```

The project includes a basic test for the ProductCard component. Add more tests in the `__tests__/` directory.

## Building for Production

### Android APK

```bash
expo build:android -t apk
```

### iOS IPA

```bash
expo build:ios -t archive
```

### Using EAS Build (Recommended)

1. Install EAS CLI:
```bash
npm install -g eas-cli
```

2. Configure your project:
```bash
eas build:configure
```

3. Build for Android:
```bash
eas build --platform android
```

4. Build for iOS:
```bash
eas build --platform ios
```

## Environment Variables

Create a `.env` file in the root directory (optional):

```
STORE_API_URL=https://your-store.com/api/graphql
```

*Note: The app supports runtime configuration, so hardcoding the URL is optional.*

## Security Notes

- JWT tokens are stored securely using Expo SecureStore
- Cart data is stored locally in AsyncStorage and synced with backend
- Never commit sensitive data or API keys to version control
- Use HTTPS endpoints in production

## Troubleshooting

### Apollo Client Errors

If you see GraphQL errors, ensure:
- The STORE_API_URL is correct
- Your backend is running and accessible
- Field names match your GraphQL schema

### Build Errors

Clear cache and reinstall:
```bash
rm -rf node_modules
npm install
expo start --clear
```

### Platform-Specific Issues

For Expo-specific issues, see: https://docs.expo.dev/troubleshooting/

## Customization

### Adapting to Your Backend

If your EverShop backend has different field names:

1. Update GraphQL queries in `src/graphql/queries.ts`
2. Update GraphQL mutations in `src/graphql/mutations.ts`
3. Adjust TypeScript types accordingly

### Adding New Screens

1. Create screen component in `src/screens/`
2. Add route in `src/App.tsx`
3. Update navigation types if needed

## License

ISC

## Support

For issues or questions about:
- **EverShop Backend**: Visit [EverShop Documentation](https://evershop.io/docs)
- **Expo/React Native**: Visit [Expo Documentation](https://docs.expo.dev/)
- **This App**: Open an issue in the repository

## Contributors

Built with ❤️ for the EverShop community
