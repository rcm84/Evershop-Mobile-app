# EverShop Mobile - React Native App

## Project Type
This is a **React Native mobile application** built with Expo that consumes the EverShop GraphQL API.

## Important Note
This is a **mobile app**, not a web application. It cannot be previewed directly in the browser like a website. To test and run this app, you need to:

1. Use the Expo Go app on your physical device (iOS/Android)
2. Use an Android/iOS emulator on your computer
3. Build the app as an APK (Android) or IPA (iOS) for distribution

## How to Run This App

### Option 1: Using Expo Go App (Recommended for Testing)

1. Install Expo Go on your mobile device:
   - iOS: Download from App Store
   - Android: Download from Google Play Store

2. Start the development server:
   ```bash
   npm start
   ```

3. Scan the QR code that appears with:
   - iOS: Camera app
   - Android: Expo Go app

### Option 2: Using an Emulator

For Android:
```bash
npm run android
```

For iOS (macOS only):
```bash
npm run ios
```

### Option 3: Build for Distribution

Using EAS Build:
```bash
npm install -g eas-cli
eas build --platform android
eas build --platform ios
```

## Project Structure

```
├── src/
│   ├── apollo/          # GraphQL client configuration
│   ├── components/      # Reusable UI components
│   ├── graphql/         # GraphQL queries & mutations
│   ├── hooks/           # Custom React hooks (useAuth, useCart)
│   ├── screens/         # App screens (Home, Product, Cart, etc.)
│   ├── themes/          # Theme configuration (colors, typography)
│   ├── utils/           # Storage utilities
│   └── App.tsx          # Main app component
├── __tests__/           # Jest tests
├── App.tsx              # Entry point
├── package.json
└── README.md            # Full documentation
```

## Features Implemented

✅ Authentication with JWT (SecureStore)
✅ Product browsing with search and filters
✅ Product detail view
✅ Shopping cart (AsyncStorage + backend sync)
✅ Checkout flow
✅ Runtime API URL configuration
✅ Theming system
✅ TypeScript
✅ Jest testing setup

## Configuration

### Backend API URL

The app reads the GraphQL API URL from:
1. Runtime settings (Settings screen in app)
2. `app.json` extra config
3. Falls back to: `https://demo.evershop.local/api/graphql`

To change the backend URL, either:
- Update `app.json` → `expo.extra.storeApiUrl`
- Use the Settings screen in the app (runtime configuration)

## Tech Stack

- React Native + Expo (managed workflow)
- TypeScript
- Apollo Client (GraphQL)
- React Navigation
- Expo SecureStore (JWT storage)
- AsyncStorage (cart persistence)

## Demo Credentials

Email: demo@evershop.io
Password: demo123

## Next Steps

1. Configure your EverShop backend URL
2. Test on Expo Go or emulator
3. Customize theme in `src/themes/default.json`
4. Adapt GraphQL queries to match your schema
5. Build for production when ready

See README.md for complete documentation.
