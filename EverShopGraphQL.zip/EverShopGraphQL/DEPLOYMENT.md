# Deployment Guide - EverShop Mobile

This React Native app is designed for mobile devices (iOS and Android). It cannot be deployed as a traditional website.

## Deployment Options

### 1. Expo Go (Development & Testing)

Perfect for development and testing. No build required.

**Steps:**
1. Install Expo Go on your device
2. Run `npm start` on your development machine
3. Scan the QR code with Expo Go app

### 2. Build Standalone APK/IPA

For distribution to users without Expo Go.

#### Using EAS Build (Recommended)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account
eas login

# Configure project
eas build:configure

# Build for Android
eas build --platform android --profile production

# Build for iOS
eas build --platform ios --profile production
```

#### Classic Expo Build

```bash
# For Android APK
expo build:android -t apk

# For iOS Archive
expo build:ios -t archive
```

### 3. App Store Distribution

#### Google Play Store (Android)

1. Build AAB (Android App Bundle):
   ```bash
   eas build --platform android --profile production
   ```

2. Create Google Play Developer account ($25 one-time fee)

3. Upload AAB to Google Play Console

4. Complete store listing (screenshots, description, etc.)

5. Submit for review

#### Apple App Store (iOS)

1. Build IPA:
   ```bash
   eas build --platform ios --profile production
   ```

2. Enroll in Apple Developer Program ($99/year)

3. Upload to App Store Connect

4. Complete app metadata

5. Submit for App Review

### 4. Enterprise Distribution

For internal company apps without store distribution.

**iOS:**
- Apple Developer Enterprise Program ($299/year)
- Build with enterprise provisioning profile
- Distribute via MDM or direct download

**Android:**
- Build APK and distribute directly
- Can use Firebase App Distribution
- Or internal file server

## Build Configuration

### eas.json Example

Create `eas.json` in project root:

```json
{
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal",
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "app-bundle"
      },
      "ios": {
        "autoIncrement": true
      }
    }
  }
}
```

### App Signing

**Android:**
- EAS handles signing automatically
- Or provide your own keystore

**iOS:**
- EAS handles provisioning and signing
- Or use your own certificates

## Environment Variables

For production builds, set environment variables:

```bash
# In eas.json
{
  "build": {
    "production": {
      "env": {
        "STORE_API_URL": "https://your-production-api.com/api/graphql"
      }
    }
  }
}
```

## Testing Before Deployment

1. **Internal Testing:**
   - Use Expo Go for rapid testing
   - Build preview APK for stakeholders

2. **Beta Testing:**
   - Google Play: Internal Testing → Closed Testing → Open Testing
   - TestFlight for iOS beta testing

3. **Quality Checks:**
   - Test on multiple devices
   - Test different screen sizes
   - Test network conditions (slow/offline)
   - Test authentication flow
   - Test cart persistence

## Post-Deployment

### Over-The-Air (OTA) Updates

With Expo, you can push updates without rebuilding:

```bash
eas update --branch production --message "Bug fixes"
```

**Limitations:**
- Cannot update native code
- Cannot add new native dependencies
- Only JS/assets updates

### Monitoring

Consider adding:
- Sentry for crash reporting
- Firebase Analytics
- Custom API analytics

## Common Issues

**Build Fails:**
- Check `app.json` configuration
- Verify all dependencies are compatible
- Check EAS build logs

**App Rejected:**
- Review platform guidelines
- Add privacy policy if handling user data
- Provide test account credentials

**Runtime Crashes:**
- Test thoroughly before submission
- Use error boundaries
- Implement proper error handling

## Resources

- [Expo Documentation](https://docs.expo.dev/)
- [EAS Build Guide](https://docs.expo.dev/build/introduction/)
- [App Store Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Google Play Policies](https://play.google.com/about/developer-content-policy/)

## Support

For deployment issues:
1. Check Expo documentation
2. Visit Expo forums
3. Check stack trace in EAS build logs
4. Review platform-specific guidelines
