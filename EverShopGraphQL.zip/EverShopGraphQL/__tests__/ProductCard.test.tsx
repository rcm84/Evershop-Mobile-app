import React from 'react';
import { render } from '@testing-library/react-native';
import { ProductCard } from '../src/components/ProductCard';
import { ThemeProvider } from '../src/components/ThemeProvider';

const mockProduct = {
  productId: '1',
  name: 'Test Product',
  slug: 'test-product',
  price: {
    regular: 99.99,
    special: 79.99,
  },
  image: {
    url: 'https://example.com/test.jpg',
    alt: 'Test Product',
  },
};

describe('ProductCard', () => {
  it('renders product information correctly', () => {
    const onPressMock = jest.fn();
    
    const { getByText } = render(
      <ThemeProvider>
        <ProductCard product={mockProduct} onPress={onPressMock} />
      </ThemeProvider>
    );

    expect(getByText('Test Product')).toBeTruthy();
    expect(getByText('$79.99')).toBeTruthy();
    expect(getByText('$99.99')).toBeTruthy();
  });
});
