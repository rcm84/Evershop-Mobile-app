import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKEN_KEY = 'auth_token';
const CART_KEY = 'cart_data';
const API_URL_KEY = 'store_api_url';

export const tokenStorage = {
  async getToken(): Promise<string | null> {
    try {
      return await SecureStore.getItemAsync(TOKEN_KEY);
    } catch (error) {
      console.error('Error getting token:', error);
      return null;
    }
  },

  async setToken(token: string): Promise<void> {
    try {
      await SecureStore.setItemAsync(TOKEN_KEY, token);
    } catch (error) {
      console.error('Error setting token:', error);
      throw error;
    }
  },

  async removeToken(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync(TOKEN_KEY);
    } catch (error) {
      console.error('Error removing token:', error);
    }
  },
};

export const cartStorage = {
  async getCart(): Promise<any | null> {
    try {
      const cartData = await AsyncStorage.getItem(CART_KEY);
      return cartData ? JSON.parse(cartData) : null;
    } catch (error) {
      console.error('Error getting cart:', error);
      return null;
    }
  },

  async setCart(cart: any): Promise<void> {
    try {
      await AsyncStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch (error) {
      console.error('Error setting cart:', error);
      throw error;
    }
  },

  async clearCart(): Promise<void> {
    try {
      await AsyncStorage.removeItem(CART_KEY);
    } catch (error) {
      console.error('Error clearing cart:', error);
    }
  },
};

export const apiUrlStorage = {
  async getApiUrl(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem(API_URL_KEY);
    } catch (error) {
      console.error('Error getting API URL:', error);
      return null;
    }
  },

  async setApiUrl(url: string): Promise<void> {
    try {
      await AsyncStorage.setItem(API_URL_KEY, url);
    } catch (error) {
      console.error('Error setting API URL:', error);
      throw error;
    }
  },
};
