import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@apollo/client';
import { QUERY_CART } from '../graphql/queries';
import { 
  MUTATION_ADD_TO_CART, 
  MUTATION_UPDATE_CART_ITEM, 
  MUTATION_REMOVE_CART_ITEM 
} from '../graphql/mutations';
import { cartStorage } from '../utils/storage';

export const useCart = () => {
  const [localCart, setLocalCart] = useState<any>(null);
  
  const { data: cartData, refetch } = useQuery(QUERY_CART, {
    fetchPolicy: 'cache-and-network',
  });

  const [addToCartMutation] = useMutation(MUTATION_ADD_TO_CART);
  const [updateCartItemMutation] = useMutation(MUTATION_UPDATE_CART_ITEM);
  const [removeCartItemMutation] = useMutation(MUTATION_REMOVE_CART_ITEM);

  useEffect(() => {
    loadLocalCart();
  }, []);

  useEffect(() => {
    if (cartData?.cart) {
      setLocalCart(cartData.cart);
      cartStorage.setCart(cartData.cart);
    }
  }, [cartData]);

  const loadLocalCart = async () => {
    try {
      const saved = await cartStorage.getCart();
      if (saved) {
        setLocalCart(saved);
      }
    } catch (error) {
      console.error('Error loading cart:', error);
    }
  };

  const addToCart = async (productId: number, qty: number, variantOptions?: string) => {
    try {
      const { data } = await addToCartMutation({
        variables: { productId, qty, variantOptions },
      });

      if (data?.addToCart?.cart) {
        setLocalCart(data.addToCart.cart);
        await cartStorage.setCart(data.addToCart.cart);
        await refetch();
        return { success: true };
      }

      return { success: false, error: 'Failed to add item to cart' };
    } catch (error: any) {
      console.error('Add to cart error:', error);
      return { 
        success: false, 
        error: error.message || 'Failed to add item to cart' 
      };
    }
  };

  const updateCartItem = async (cartItemId: string, qty: number) => {
    try {
      const { data } = await updateCartItemMutation({
        variables: { cartItemId, qty },
      });

      if (data?.updateCartItem?.cart) {
        setLocalCart(data.updateCartItem.cart);
        await cartStorage.setCart(data.updateCartItem.cart);
        await refetch();
        return { success: true };
      }

      return { success: false, error: 'Failed to update cart item' };
    } catch (error: any) {
      console.error('Update cart item error:', error);
      return { 
        success: false, 
        error: error.message || 'Failed to update cart item' 
      };
    }
  };

  const removeCartItem = async (cartItemId: string) => {
    try {
      const { data } = await removeCartItemMutation({
        variables: { cartItemId },
      });

      if (data?.removeCartItem?.cart) {
        setLocalCart(data.removeCartItem.cart);
        await cartStorage.setCart(data.removeCartItem.cart);
        await refetch();
        return { success: true };
      }

      return { success: false, error: 'Failed to remove cart item' };
    } catch (error: any) {
      console.error('Remove cart item error:', error);
      return { 
        success: false, 
        error: error.message || 'Failed to remove cart item' 
      };
    }
  };

  const clearCart = async () => {
    await cartStorage.clearCart();
    setLocalCart(null);
  };

  const cart = localCart || cartData?.cart;
  const itemCount = cart?.items?.reduce((sum: number, item: any) => sum + item.qty, 0) || 0;

  return {
    cart,
    itemCount,
    addToCart,
    updateCartItem,
    removeCartItem,
    clearCart,
    refetch,
  };
};
