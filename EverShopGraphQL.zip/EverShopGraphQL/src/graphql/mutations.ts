import { gql } from '@apollo/client';

export const AUTH_MUTATION_LOGIN = gql`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      status
      token
      customer {
        customerId
        email
        firstName
        lastName
      }
    }
  }
`;

export const AUTH_MUTATION_LOGOUT = gql`
  mutation Logout {
    logout {
      status
    }
  }
`;

export const MUTATION_ADD_TO_CART = gql`
  mutation AddToCart($productId: Int!, $qty: Int!, $variantOptions: String) {
    addToCart(
      cartItem: { productId: $productId, qty: $qty, variantOptions: $variantOptions }
    ) {
      status
      cart {
        cartId
        items {
          cartItemId
          productId
          productName
          qty
          price
          finalPrice
        }
        subTotal
        grandTotal
      }
    }
  }
`;

export const MUTATION_UPDATE_CART_ITEM = gql`
  mutation UpdateCartItem($cartItemId: String!, $qty: Int!) {
    updateCartItem(cartItemId: $cartItemId, qty: $qty) {
      status
      cart {
        cartId
        items {
          cartItemId
          productId
          productName
          qty
          price
          finalPrice
        }
        subTotal
        grandTotal
      }
    }
  }
`;

export const MUTATION_REMOVE_CART_ITEM = gql`
  mutation RemoveCartItem($cartItemId: String!) {
    removeCartItem(cartItemId: $cartItemId) {
      status
      cart {
        cartId
        items {
          cartItemId
          productId
          productName
          qty
          price
          finalPrice
        }
        subTotal
        grandTotal
      }
    }
  }
`;

export const MUTATION_CREATE_ORDER = gql`
  mutation CreateOrder(
    $cartId: String!
    $shippingAddress: AddressInput!
    $billingAddress: AddressInput!
    $paymentMethod: String!
    $shippingMethod: String!
  ) {
    createOrder(
      order: {
        cartId: $cartId
        shippingAddress: $shippingAddress
        billingAddress: $billingAddress
        paymentMethod: $paymentMethod
        shippingMethod: $shippingMethod
      }
    ) {
      status
      orderId
      orderNumber
      grandTotal
      paymentUrl
    }
  }
`;
