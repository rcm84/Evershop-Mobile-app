import { gql } from '@apollo/client';

export const QUERY_PRODUCTS = gql`
  query GetProducts($page: Int, $limit: Int, $search: String, $categoryId: String) {
    products(
      filters: {
        page: $page
        limit: $limit
        search: $search
        categoryId: $categoryId
      }
    ) {
      items {
        productId
        name
        slug
        price {
          regular
          special
        }
        image {
          url
          alt
        }
        description
        sku
      }
      total
      currentPage
      totalPages
    }
  }
`;

export const QUERY_PRODUCT_BY_SLUG = gql`
  query GetProductBySlug($slug: String!) {
    product(slug: $slug) {
      productId
      name
      slug
      price {
        regular
        special
      }
      images {
        url
        alt
      }
      description
      sku
      qty
      variants {
        variantId
        name
        options {
          optionId
          optionName
          values {
            valueId
            valueName
          }
        }
      }
      categories {
        categoryId
        name
      }
    }
  }
`;

export const QUERY_CATEGORIES = gql`
  query GetCategories {
    categories {
      categoryId
      name
      description
      image {
        url
        alt
      }
    }
  }
`;

export const QUERY_CART = gql`
  query GetCart {
    cart {
      cartId
      items {
        cartItemId
        productId
        productName
        productSku
        qty
        price
        finalPrice
        image {
          url
          alt
        }
        variantOptions
      }
      subTotal
      grandTotal
      couponCode
      discountAmount
    }
  }
`;

export const QUERY_CUSTOMER = gql`
  query GetCustomer {
    customer {
      customerId
      email
      firstName
      lastName
      status
    }
  }
`;
