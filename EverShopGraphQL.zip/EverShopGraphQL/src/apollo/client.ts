import { ApolloClient, InMemoryCache, createHttpLink, NormalizedCacheObject } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import { tokenStorage, apiUrlStorage } from '../utils/storage';
import Constants from 'expo-constants';

let apolloClient: ApolloClient<NormalizedCacheObject> | null = null;

export const getApiUrl = async (): Promise<string> => {
  const storedUrl = await apiUrlStorage.getApiUrl();
  if (storedUrl) {
    return storedUrl;
  }
  
  const extraConfig = Constants.expoConfig?.extra;
  return extraConfig?.storeApiUrl || 'https://demo.evershop.local/api/graphql';
};

export const createApolloClient = async () => {
  const apiUrl = await getApiUrl();

  const httpLink = createHttpLink({
    uri: apiUrl,
  });

  const authLink = setContext(async (_, { headers }) => {
    const token = await tokenStorage.getToken();
    
    return {
      headers: {
        ...headers,
        authorization: token ? `Bearer ${token}` : '',
        'Content-Type': 'application/json',
      },
    };
  });

  return new ApolloClient({
    link: authLink.concat(httpLink),
    cache: new InMemoryCache(),
    defaultOptions: {
      watchQuery: {
        fetchPolicy: 'cache-and-network',
        errorPolicy: 'all',
      },
      query: {
        fetchPolicy: 'network-only',
        errorPolicy: 'all',
      },
      mutate: {
        errorPolicy: 'all',
      },
    },
  });
};

export const getApolloClient = async () => {
  if (!apolloClient) {
    apolloClient = await createApolloClient();
  }
  return apolloClient;
};

export const resetApolloClient = async () => {
  apolloClient = await createApolloClient();
  return apolloClient;
};
