import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Linking,
} from 'react-native';
import { useMutation } from '@apollo/client';
import { MUTATION_CREATE_ORDER } from '../graphql/mutations';
import { Header } from '../components/Header';
import { useTheme } from '../components/ThemeProvider';
import { useCart } from '../hooks/useCart';

export const Checkout: React.FC<{ navigation: any }> = ({ navigation }) => {
  const theme = useTheme();
  const { cart, clearCart } = useCart();
  const [processing, setProcessing] = useState(false);
  const [orderResult, setOrderResult] = useState<any>(null);

  const [createOrderMutation] = useMutation(MUTATION_CREATE_ORDER);

  const handlePlaceOrder = async () => {
    if (!cart?.cartId) {
      Alert.alert('Error', 'Cart not found');
      return;
    }

    setProcessing(true);

    try {
      const { data } = await createOrderMutation({
        variables: {
          cartId: cart.cartId,
          shippingAddress: {
            fullName: 'Demo User',
            address1: '123 Demo Street',
            city: 'Demo City',
            province: 'Demo State',
            postcode: '12345',
            country: 'US',
            telephone: '555-0123',
          },
          billingAddress: {
            fullName: 'Demo User',
            address1: '123 Demo Street',
            city: 'Demo City',
            province: 'Demo State',
            postcode: '12345',
            country: 'US',
            telephone: '555-0123',
          },
          paymentMethod: 'demo_payment',
          shippingMethod: 'standard',
        },
      });

      if (data?.createOrder) {
        setOrderResult(data.createOrder);
        await clearCart();
      } else {
        Alert.alert('Error', 'Failed to create order');
      }
    } catch (error: any) {
      console.error('Checkout error:', error);
      Alert.alert(
        'Order Simulation',
        'This is a demo app. In production, this would process payment and create an order.\n\nOrder Total: $' +
          cart.grandTotal.toFixed(2),
        [
          {
            text: 'OK',
            onPress: async () => {
              setOrderResult({
                status: 'success',
                orderId: 'DEMO-' + Date.now(),
                orderNumber: 'ORDER-' + Math.floor(Math.random() * 10000),
                grandTotal: cart.grandTotal,
              });
              await clearCart();
            },
          },
        ]
      );
    } finally {
      setProcessing(false);
    }
  };

  const handleContinueShopping = () => {
    navigation.navigate('Home');
  };

  if (orderResult) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Header title="Order Complete" showBack={false} />

        <View style={styles.successContainer}>
          <Text style={styles.successIcon}>✓</Text>
          <Text style={[styles.successTitle, { color: theme.colors.success }]}>
            Order Placed Successfully!
          </Text>

          <View style={[styles.orderInfo, { backgroundColor: theme.colors.surface }]}>
            <View style={styles.orderRow}>
              <Text style={[styles.orderLabel, { color: theme.colors.textSecondary }]}>
                Order Number:
              </Text>
              <Text style={[styles.orderValue, { color: theme.colors.text }]}>
                {orderResult.orderNumber}
              </Text>
            </View>

            <View style={styles.orderRow}>
              <Text style={[styles.orderLabel, { color: theme.colors.textSecondary }]}>
                Total:
              </Text>
              <Text style={[styles.orderValue, { color: theme.colors.primary }]}>
                ${orderResult.grandTotal.toFixed(2)}
              </Text>
            </View>
          </View>

          {orderResult.paymentUrl && (
            <TouchableOpacity
              style={[styles.button, { backgroundColor: theme.colors.primary }]}
              onPress={() => Linking.openURL(orderResult.paymentUrl)}
            >
              <Text style={[styles.buttonText, { color: theme.colors.background }]}>
                Complete Payment
              </Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[
              styles.button,
              { backgroundColor: theme.colors.background, borderWidth: 1, borderColor: theme.colors.border },
            ]}
            onPress={handleContinueShopping}
          >
            <Text style={[styles.buttonText, { color: theme.colors.primary }]}>
              Continue Shopping
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Header title="Checkout" showBack />

      <ScrollView style={styles.scrollView}>
        <View style={styles.content}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
            Order Summary
          </Text>

          <View style={[styles.summaryCard, { backgroundColor: theme.colors.surface }]}>
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: theme.colors.textSecondary }]}>
                Items:
              </Text>
              <Text style={[styles.summaryValue, { color: theme.colors.text }]}>
                {cart?.items?.length || 0}
              </Text>
            </View>

            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: theme.colors.textSecondary }]}>
                Subtotal:
              </Text>
              <Text style={[styles.summaryValue, { color: theme.colors.text }]}>
                ${cart?.subTotal?.toFixed(2) || '0.00'}
              </Text>
            </View>

            <View style={[styles.summaryRow, styles.totalRow]}>
              <Text style={[styles.totalLabel, { color: theme.colors.text }]}>Total:</Text>
              <Text style={[styles.totalValue, { color: theme.colors.primary }]}>
                ${cart?.grandTotal?.toFixed(2) || '0.00'}
              </Text>
            </View>
          </View>

          <View style={[styles.noteCard, { backgroundColor: theme.colors.surface }]}>
            <Text style={[styles.noteText, { color: theme.colors.textSecondary }]}>
              Note: This is a demo checkout. In production, you would collect shipping/billing
              addresses and process real payments.
            </Text>
          </View>

          <TouchableOpacity
            style={[
              styles.placeOrderButton,
              { backgroundColor: theme.colors.primary },
              processing && { opacity: 0.7 },
            ]}
            onPress={handlePlaceOrder}
            disabled={processing}
          >
            {processing ? (
              <ActivityIndicator color={theme.colors.background} />
            ) : (
              <Text style={[styles.placeOrderText, { color: theme.colors.background }]}>
                Place Order
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  summaryCard: {
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 16,
  },
  summaryValue: {
    fontSize: 16,
  },
  totalRow: {
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.1)',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  noteCard: {
    padding: 16,
    borderRadius: 8,
    marginBottom: 24,
  },
  noteText: {
    fontSize: 14,
    lineHeight: 20,
  },
  placeOrderButton: {
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeOrderText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  successContainer: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  successIcon: {
    fontSize: 72,
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 32,
  },
  orderInfo: {
    width: '100%',
    padding: 20,
    borderRadius: 12,
    marginBottom: 32,
  },
  orderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  orderLabel: {
    fontSize: 16,
  },
  orderValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  button: {
    width: '100%',
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});
