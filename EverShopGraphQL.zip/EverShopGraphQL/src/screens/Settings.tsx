import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { Header } from '../components/Header';
import { useTheme } from '../components/ThemeProvider';
import { useAuth } from '../contexts/AuthContext';
import { apiUrlStorage } from '../utils/storage';
import { resetApolloClient } from '../apollo/client';

export const Settings: React.FC<{ navigation: any }> = ({ navigation }) => {
  const theme = useTheme();
  const { isAuthenticated, user, logout } = useAuth();
  const [apiUrl, setApiUrl] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadApiUrl();
  }, []);

  const loadApiUrl = async () => {
    const stored = await apiUrlStorage.getApiUrl();
    setApiUrl(stored || 'https://demo.evershop.local/api/graphql');
  };

  const handleSaveApiUrl = async () => {
    if (!apiUrl.trim()) {
      Alert.alert('Error', 'Please enter a valid API URL');
      return;
    }

    try {
      setLoading(true);
      await apiUrlStorage.setApiUrl(apiUrl);
      await resetApolloClient();
      Alert.alert('Success', 'API URL updated. Please restart the app for changes to take effect.');
    } catch (error) {
      Alert.alert('Error', 'Failed to save API URL');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await logout();
          navigation.replace('Login');
        },
      },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Header title="Settings" showBack />

      <ScrollView style={styles.scrollView}>
        <View style={styles.content}>
          {isAuthenticated && user && (
            <View style={[styles.section, { backgroundColor: theme.colors.surface }]}>
              <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
                Account
              </Text>
              <Text style={[styles.infoText, { color: theme.colors.textSecondary }]}>
                {user.email}
              </Text>
              <TouchableOpacity
                style={[styles.logoutButton, { borderColor: theme.colors.danger }]}
                onPress={handleLogout}
              >
                <Text style={[styles.logoutText, { color: theme.colors.danger }]}>
                  Logout
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
              Store Configuration
            </Text>
            <Text style={[styles.label, { color: theme.colors.textSecondary }]}>
              GraphQL API URL
            </Text>
            <TextInput
              style={[
                styles.input,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                  color: theme.colors.text,
                },
              ]}
              placeholder="https://your-store.com/api/graphql"
              placeholderTextColor={theme.colors.placeholder}
              value={apiUrl}
              onChangeText={setApiUrl}
              autoCapitalize="none"
              autoCorrect={false}
            />

            <TouchableOpacity
              style={[
                styles.saveButton,
                { backgroundColor: theme.colors.primary },
                loading && { opacity: 0.7 },
              ]}
              onPress={handleSaveApiUrl}
              disabled={loading}
            >
              <Text style={[styles.saveButtonText, { color: theme.colors.background }]}>
                {loading ? 'Saving...' : 'Save Changes'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.infoCard, { backgroundColor: theme.colors.surface }]}>
            <Text style={[styles.infoTitle, { color: theme.colors.text }]}>
              About
            </Text>
            <Text style={[styles.infoText, { color: theme.colors.textSecondary }]}>
              EverShop Mobile - v1.0.0
            </Text>
            <Text style={[styles.infoText, { color: theme.colors.textSecondary }]}>
              A React Native mobile app for EverShop e-commerce platform.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 24,
    padding: 16,
    borderRadius: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    marginBottom: 8,
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 14,
    marginBottom: 16,
  },
  saveButton: {
    height: 50,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutButton: {
    height: 44,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    marginTop: 12,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
  },
  infoCard: {
    padding: 16,
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 4,
  },
});
