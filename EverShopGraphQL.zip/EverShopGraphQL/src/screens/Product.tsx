import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useQuery } from '@apollo/client';
import { QUERY_PRODUCT_BY_SLUG } from '../graphql/queries';
import { Header } from '../components/Header';
import { QuantityPicker } from '../components/QuantityPicker';
import { useTheme } from '../components/ThemeProvider';
import { useCart } from '../hooks/useCart';

export const Product: React.FC<{ route: any; navigation: any }> = ({ route, navigation }) => {
  const theme = useTheme();
  const { slug } = route.params;
  const { addToCart, itemCount } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [adding, setAdding] = useState(false);

  const { data, loading } = useQuery(QUERY_PRODUCT_BY_SLUG, {
    variables: { slug },
  });

  const product = data?.product;

  const handleAddToCart = async () => {
    if (!product) return;

    setAdding(true);
    const result = await addToCart(parseInt(product.productId), quantity);
    setAdding(false);

    if (result.success) {
      Alert.alert('Success', 'Product added to cart', [
        { text: 'Continue Shopping', style: 'cancel' },
        { text: 'View Cart', onPress: () => navigation.navigate('Cart') },
      ]);
    } else {
      Alert.alert('Error', result.error || 'Failed to add to cart');
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Header title="Product" showBack showCart cartItemCount={itemCount} />
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      </View>
    );
  }

  if (!product) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Header title="Product" showBack showCart cartItemCount={itemCount} />
        <View style={styles.loader}>
          <Text style={{ color: theme.colors.textSecondary }}>Product not found</Text>
        </View>
      </View>
    );
  }

  const displayPrice = product.price.special || product.price.regular;
  const hasDiscount = product.price.special && product.price.special < product.price.regular;
  const mainImage = product.images?.[0] || product.image;

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Header title={product.name} showBack showCart cartItemCount={itemCount} />
      
      <ScrollView style={styles.scrollView}>
        {mainImage?.url ? (
          <Image 
            source={{ uri: mainImage.url }} 
            style={styles.image}
            resizeMode="cover"
          />
        ) : (
          <View style={[styles.imagePlaceholder, { backgroundColor: theme.colors.surface }]}>
            <Text style={{ color: theme.colors.textSecondary }}>No Image</Text>
          </View>
        )}

        <View style={styles.content}>
          <Text style={[styles.name, { color: theme.colors.text }]}>
            {product.name}
          </Text>

          <View style={styles.priceContainer}>
            <Text style={[styles.price, { color: theme.colors.primary }]}>
              ${displayPrice.toFixed(2)}
            </Text>
            {hasDiscount && (
              <Text style={[styles.originalPrice, { color: theme.colors.textSecondary }]}>
                ${product.price.regular.toFixed(2)}
              </Text>
            )}
          </View>

          {product.description && (
            <View style={styles.section}>
              <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
                Description
              </Text>
              <Text style={[styles.description, { color: theme.colors.textSecondary }]}>
                {product.description}
              </Text>
            </View>
          )}

          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
              Quantity
            </Text>
            <QuantityPicker
              quantity={quantity}
              onIncrease={() => setQuantity(q => q + 1)}
              onDecrease={() => setQuantity(q => q - 1)}
            />
          </View>

          <TouchableOpacity
            style={[
              styles.addButton,
              { backgroundColor: theme.colors.primary },
              adding && { opacity: 0.7 }
            ]}
            onPress={handleAddToCart}
            disabled={adding}
          >
            {adding ? (
              <ActivityIndicator color={theme.colors.background} />
            ) : (
              <Text style={[styles.addButtonText, { color: theme.colors.background }]}>
                Add to Cart
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: 300,
  },
  imagePlaceholder: {
    width: '100%',
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  price: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  originalPrice: {
    fontSize: 20,
    textDecorationLine: 'line-through',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
  },
  addButton: {
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  addButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});
