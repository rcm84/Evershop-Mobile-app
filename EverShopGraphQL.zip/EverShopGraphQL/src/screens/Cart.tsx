import React from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { Header } from '../components/Header';
import { QuantityPicker } from '../components/QuantityPicker';
import { useTheme } from '../components/ThemeProvider';
import { useCart } from '../hooks/useCart';

export const Cart: React.FC<{ navigation: any }> = ({ navigation }) => {
  const theme = useTheme();
  const { cart, itemCount, updateCartItem, removeCartItem } = useCart();

  const handleQuantityChange = async (cartItemId: string, newQty: number) => {
    const result = await updateCartItem(cartItemId, newQty);
    if (!result.success) {
      Alert.alert('Error', result.error || 'Failed to update quantity');
    }
  };

  const handleRemoveItem = async (cartItemId: string) => {
    Alert.alert(
      'Remove Item',
      'Are you sure you want to remove this item from cart?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            const result = await removeCartItem(cartItemId);
            if (!result.success) {
              Alert.alert('Error', result.error || 'Failed to remove item');
            }
          },
        },
      ]
    );
  };

  const handleCheckout = () => {
    if (!cart || cart.items.length === 0) {
      Alert.alert('Empty Cart', 'Please add items to cart before checkout');
      return;
    }
    navigation.navigate('Checkout');
  };

  const items = cart?.items || [];

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Header title="Shopping Cart" showBack />

      {items.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={[styles.emptyText, { color: theme.colors.textSecondary }]}>
            Your cart is empty
          </Text>
          <TouchableOpacity
            style={[styles.shopButton, { backgroundColor: theme.colors.primary }]}
            onPress={() => navigation.navigate('Home')}
          >
            <Text style={[styles.shopButtonText, { color: theme.colors.background }]}>
              Continue Shopping
            </Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <FlatList
            data={items}
            keyExtractor={(item) => item.cartItemId}
            renderItem={({ item }) => (
              <View
                style={[
                  styles.cartItem,
                  { backgroundColor: theme.colors.card, borderColor: theme.colors.border },
                ]}
              >
                {item.image?.url ? (
                  <Image source={{ uri: item.image.url }} style={styles.itemImage} />
                ) : (
                  <View style={[styles.imagePlaceholder, { backgroundColor: theme.colors.surface }]}>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 12 }}>
                      No Image
                    </Text>
                  </View>
                )}

                <View style={styles.itemDetails}>
                  <Text style={[styles.itemName, { color: theme.colors.text }]} numberOfLines={2}>
                    {item.productName}
                  </Text>
                  <Text style={[styles.itemPrice, { color: theme.colors.primary }]}>
                    ${item.finalPrice.toFixed(2)}
                  </Text>

                  <View style={styles.itemActions}>
                    <QuantityPicker
                      quantity={item.qty}
                      onIncrease={() => handleQuantityChange(item.cartItemId, item.qty + 1)}
                      onDecrease={() => handleQuantityChange(item.cartItemId, item.qty - 1)}
                    />

                    <TouchableOpacity
                      style={[styles.removeButton, { borderColor: theme.colors.danger }]}
                      onPress={() => handleRemoveItem(item.cartItemId)}
                    >
                      <Text style={[styles.removeText, { color: theme.colors.danger }]}>
                        Remove
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
            contentContainerStyle={styles.listContent}
          />

          <View style={[styles.footer, { borderTopColor: theme.colors.border }]}>
            <View style={styles.totalRow}>
              <Text style={[styles.totalLabel, { color: theme.colors.text }]}>Subtotal:</Text>
              <Text style={[styles.totalValue, { color: theme.colors.text }]}>
                ${cart?.subTotal?.toFixed(2) || '0.00'}
              </Text>
            </View>

            <View style={styles.totalRow}>
              <Text style={[styles.grandTotalLabel, { color: theme.colors.text }]}>Total:</Text>
              <Text style={[styles.grandTotalValue, { color: theme.colors.primary }]}>
                ${cart?.grandTotal?.toFixed(2) || '0.00'}
              </Text>
            </View>

            <TouchableOpacity
              style={[styles.checkoutButton, { backgroundColor: theme.colors.primary }]}
              onPress={handleCheckout}
            >
              <Text style={[styles.checkoutButtonText, { color: theme.colors.background }]}>
                Proceed to Checkout
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    fontSize: 18,
    marginBottom: 24,
  },
  shopButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  shopButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  listContent: {
    padding: 16,
  },
  cartItem: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 12,
  },
  itemImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  imagePlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemDetails: {
    flex: 1,
    marginLeft: 12,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  itemPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  itemActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  removeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    borderWidth: 1,
  },
  removeText: {
    fontSize: 14,
    fontWeight: '600',
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  totalLabel: {
    fontSize: 16,
  },
  totalValue: {
    fontSize: 16,
  },
  grandTotalLabel: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  grandTotalValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  checkoutButton: {
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  checkoutButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});
