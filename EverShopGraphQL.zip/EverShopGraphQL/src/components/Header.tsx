import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from './ThemeProvider';
import { useNavigation } from '@react-navigation/native';

interface HeaderProps {
  title: string;
  showBack?: boolean;
  showCart?: boolean;
  cartItemCount?: number;
}

export const Header: React.FC<HeaderProps> = ({ 
  title, 
  showBack = false, 
  showCart = false,
  cartItemCount = 0 
}) => {
  const theme = useTheme();
  const navigation = useNavigation();

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.primary }]}>
      {showBack && (
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={[styles.backText, { color: theme.colors.background }]}>
            ← Back
          </Text>
        </TouchableOpacity>
      )}
      
      <Text style={[styles.title, { color: theme.colors.background }]}>
        {title}
      </Text>

      {showCart && (
        <TouchableOpacity 
          style={styles.cartButton}
          onPress={() => (navigation as any).navigate('Cart')}
        >
          <Text style={[styles.cartIcon, { color: theme.colors.background }]}>
            🛒
          </Text>
          {cartItemCount > 0 && (
            <View style={[styles.badge, { backgroundColor: theme.colors.danger }]}>
              <Text style={[styles.badgeText, { color: theme.colors.background }]}>
                {cartItemCount}
              </Text>
            </View>
          )}
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  backButton: {
    position: 'absolute',
    left: 16,
    top: 20,
  },
  backText: {
    fontSize: 16,
    fontWeight: '600',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cartButton: {
    position: 'absolute',
    right: 16,
    top: 20,
  },
  cartIcon: {
    fontSize: 24,
  },
  badge: {
    position: 'absolute',
    top: -5,
    right: -5,
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
});
