import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from './ThemeProvider';

interface QuantityPickerProps {
  quantity: number;
  onIncrease: () => void;
  onDecrease: () => void;
  min?: number;
  max?: number;
}

export const QuantityPicker: React.FC<QuantityPickerProps> = ({ 
  quantity, 
  onIncrease, 
  onDecrease,
  min = 1,
  max = 99
}) => {
  const theme = useTheme();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.button,
          { 
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.border,
            opacity: quantity <= min ? 0.5 : 1
          }
        ]}
        onPress={onDecrease}
        disabled={quantity <= min}
      >
        <Text style={[styles.buttonText, { color: theme.colors.text }]}>−</Text>
      </TouchableOpacity>

      <View style={[styles.quantityContainer, { backgroundColor: theme.colors.surface }]}>
        <Text style={[styles.quantity, { color: theme.colors.text }]}>
          {quantity}
        </Text>
      </View>

      <TouchableOpacity
        style={[
          styles.button,
          { 
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.border,
            opacity: quantity >= max ? 0.5 : 1
          }
        ]}
        onPress={onIncrease}
        disabled={quantity >= max}
      >
        <Text style={[styles.buttonText, { color: theme.colors.text }]}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  button: {
    width: 36,
    height: 36,
    borderRadius: 8,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  quantityContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    minWidth: 50,
    alignItems: 'center',
  },
  quantity: {
    fontSize: 16,
    fontWeight: '600',
  },
});
