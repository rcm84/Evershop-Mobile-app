import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from './ThemeProvider';

interface ProductCardProps {
  product: {
    productId: string;
    name: string;
    slug: string;
    price: {
      regular: number;
      special?: number;
    };
    image?: {
      url: string;
      alt?: string;
    };
  };
  onPress: () => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onPress }) => {
  const theme = useTheme();
  const displayPrice = product.price.special || product.price.regular;
  const hasDiscount = product.price.special && product.price.special < product.price.regular;

  return (
    <TouchableOpacity 
      style={[styles.card, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]} 
      onPress={onPress}
    >
      {product.image?.url ? (
        <Image 
          source={{ uri: product.image.url }} 
          style={styles.image}
          resizeMode="cover"
        />
      ) : (
        <View style={[styles.imagePlaceholder, { backgroundColor: theme.colors.surface }]}>
          <Text style={{ color: theme.colors.textSecondary }}>No Image</Text>
        </View>
      )}
      
      <View style={styles.content}>
        <Text 
          style={[styles.name, { color: theme.colors.text }]} 
          numberOfLines={2}
        >
          {product.name}
        </Text>
        
        <View style={styles.priceContainer}>
          <Text style={[styles.price, { color: theme.colors.primary }]}>
            ${displayPrice.toFixed(2)}
          </Text>
          {hasDiscount && (
            <Text style={[styles.originalPrice, { color: theme.colors.textSecondary }]}>
              ${product.price.regular.toFixed(2)}
            </Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: 16,
  },
  image: {
    width: '100%',
    height: 200,
  },
  imagePlaceholder: {
    width: '100%',
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  originalPrice: {
    fontSize: 14,
    textDecorationLine: 'line-through',
  },
});
